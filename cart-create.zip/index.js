const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  // 1. Verificar token
  const token = event.headers.Authorization.split(' ')[1];
  let userId;
  
  try {
    const decoded = jwt.verify(token, 'secreto');
    userId = decoded.userId;
  } catch (error) {
    return { statusCode: 401, body: JSON.stringify({ error: 'Token inválido' }) };
  }

  // 2. Extraer datos del carrito
  const { products, total } = JSON.parse(event.body);

  // 3. Guardar en DynamoDB
  const newCart = {
    uuid: uuidv4(),
    userId,
    products,
    total,
    createdAt: new Date().toISOString()
  };

  await dynamoDB.put({
    TableName: 'ElectroCart',
    Item: newCart
  }).promise();

  return {
    statusCode: 201,
    body: JSON.stringify({
      message: "Carrito creado exitosamente",
      data: newCart
    })
  };
};